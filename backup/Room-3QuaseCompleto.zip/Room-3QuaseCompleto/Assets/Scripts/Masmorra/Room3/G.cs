﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class G : MonoBehaviour
{
    public GameObject Object;
    private bool _mousenoOBJ = false;
  void Start()
  {
      Object.SetActive(false);
  }
  void Update()
  {
      if( _mousenoOBJ && Input.GetMouseButtonDown(0)){
        print("G");
        Object.SetActive(true);
      } 
  }
 
  void OnMouseEnter()
  {
    _mousenoOBJ = true;
  }
  void OnMouseExit()
  {
    _mousenoOBJ = false;
  }
  public void Fechar(){
    Object.SetActive(false);
  }
}
