﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class E : MonoBehaviour
{
   
   private bool _MousenaPlaca = false;

   
   void Update()
   {
       if( _MousenaPlaca && Input.GetMouseButtonDown(0)){
        print("E");
      } 
   }
  void OnMouseEnter()
  {
      print("Pressione Para Ler");
      _MousenaPlaca = true;
  }
  
  void OnMouseExit()
  {
    _MousenaPlaca = false;
  }
}