using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class R : MonoBehaviour
{
    private bool _Mouse = false;
 
  
  /// <summary>
  /// Update is called every frame, if the MonoBehaviour is enabled.
  /// </summary>
  void Update()
  {
      if( _Mouse && Input.GetMouseButtonDown(0)){
        print("R");
      } 
  }
  /// <summary>
  /// Called when the mouse enters the GUIElement or Collider.
  /// </summary>
  void OnMouseEnter()
  {
    print("Dentro");
      _Mouse = true;
      
  }
  /// <summary>
  /// Called when the mouse is not any longer over the GUIElement or Collider.
  /// </summary>
  void OnMouseExit()
  {
    _Mouse = false;
  }
}
