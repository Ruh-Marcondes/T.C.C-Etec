<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="gramaComAssets" tilewidth="32" tileheight="32" tilecount="40" columns="8">
 <image source="gramaComAssets.png" width="256" height="160"/>
 <terraintypes>
  <terrain name="Novo Terreno" tile="0"/>
 </terraintypes>
 <tile id="16" terrain=",,,0"/>
 <tile id="17" terrain=",,0,0"/>
 <tile id="18" terrain=",,0,"/>
 <tile id="24" terrain=",0,,0"/>
 <tile id="25" terrain="0,0,0,0"/>
 <tile id="26" terrain="0,,0,"/>
 <tile id="32" terrain=",0,,"/>
 <tile id="33" terrain="0,0,,"/>
 <tile id="34" terrain="0,,,"/>
</tileset>
