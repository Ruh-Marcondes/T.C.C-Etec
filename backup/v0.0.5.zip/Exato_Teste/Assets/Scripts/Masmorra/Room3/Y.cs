﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Y : MonoBehaviour
{
    private bool _naPlaca = false;
    void Update()
    {
        if(_naPlaca && Input.GetMouseButtonDown(0)){
            print("Y");
        }
    }
    void OnMouseEnter()
    {
        print("Press To read");
        _naPlaca = true;
    }
    void OnMouseExit()
    {
        _naPlaca = false;
    }
    
}
