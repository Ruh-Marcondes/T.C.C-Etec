﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ContrlollerCamera_Rooms : MonoBehaviour
{
    
    public Vector2 newposition1;
    public GameObject cam;
     public void changePositionCamera(){
    
     }
}
