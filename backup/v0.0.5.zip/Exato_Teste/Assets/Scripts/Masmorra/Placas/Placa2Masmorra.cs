﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Placa2Masmorra : MonoBehaviour
{
    public Text tx;
    public InputField ok;
    public GameObject alan, blue, NPC;
    public int ID;
    public static bool platercantmove = true;
    public static bool SenhaCerta = false;
    
    void Start()
    {
        blue.SetActive(false);
        NPC.SetActive(false);
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.tag=="Player"){
            platercantmove = false;
            if(ID==2){
            tx.text = "\"- Eu tenho a cor do cêu, e me assusto facilmente;\n\t- Eu tenho a cor do Sol, e sustos não entram na minha mente;\n\t- Tenho as duas cores e se me asustar fico verde \n E agora você nos vê\"";
            alan.SetActive(true);
            NPC.SetActive(true);
            }
            if(ID==3){
                tx.text = "Bem - Vindo ao Museu";
             blue.SetActive(true);
            }     
        }
    }
    public void verificaSenha(){
        string senha;
        senha = ok.text.ToUpper();
        Debug.Log(senha);
        if(senha != "UT"){
            ok.text = "";
            senha = "";
        }else{
            platercantmove = true;
            SenhaCerta = true;
            blue.SetActive(false);
        }
        
    }
    public void CloseSenha(){
        platercantmove = true;
        blue.SetActive(false);
    }
}