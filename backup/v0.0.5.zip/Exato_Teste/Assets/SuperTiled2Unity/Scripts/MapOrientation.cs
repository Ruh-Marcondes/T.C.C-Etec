﻿namespace SuperTiled2Unity
{
    public enum MapOrientation
    {
        Orthogonal,
        Isometric,
        Staggered,
        Hexagonal,
    }
}
