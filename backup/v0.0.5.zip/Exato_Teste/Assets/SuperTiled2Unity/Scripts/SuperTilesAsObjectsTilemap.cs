﻿using UnityEngine;

namespace SuperTiled2Unity
{
    // Component to put on a "fake tilemap" layer that places tiles as objects
    public class SuperTilesAsObjectsTilemap : MonoBehaviour
    {
    }
}
