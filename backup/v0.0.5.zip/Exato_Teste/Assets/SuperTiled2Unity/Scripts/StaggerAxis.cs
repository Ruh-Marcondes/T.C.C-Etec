﻿namespace SuperTiled2Unity
{
    public enum StaggerAxis
    {
        X,
        Y,
    }
}
