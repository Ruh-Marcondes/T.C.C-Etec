﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Placa2Masmorra : MonoBehaviour
{
    public Text tx;
    public InputField ok;
    public GameObject alan, blue;
    public int ID;
    public static bool platercantmove = true;
    public static bool SenhaCerta = false;
    
    void Start()
    {
        blue.SetActive(false);
    }
    void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.tag=="Player"){
            platercantmove = false;
            if(ID==2){
            tx.text = "Para a porta se abrir arrume os Munls nos seus lugares";
             alan.SetActive(true);
            }
            if(ID==3){
             blue.SetActive(true);
            }     
        }
    }
    public void verificaSenha(){
        string senha;
        senha = tx.text.ToUpper();
        Debug.Log(senha);
        if(senha == "UT"){
            platercantmove = true;
            SenhaCerta = true;
            blue.SetActive(false);
        }else{
            ok.text = " ";
        }
        
    }
    public void CloseSenha(){
        platercantmove = true;
        blue.SetActive(false);
    }
}
