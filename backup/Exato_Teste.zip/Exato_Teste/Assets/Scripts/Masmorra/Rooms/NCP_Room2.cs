using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NCP_Room2 : MonoBehaviour{
    public static int TOTAL_AZUL = 1;
    public static int TOTAL_AMARELO = 1;
    public int id;
        
    void OnCollisionEnter2D(Collision2D other)
    {
        if(other.gameObject.tag=="Player"){
            if(gameObject.tag=="Amarelo"){
                Debug.Log(transform.position);
                MoveParaAmarelo();
                return ;
               // TOTAL_AMARELO--;
                
            }
            if(gameObject.tag=="Azul"){
                MoveParaAzul();
                TOTAL_AZUL--;
               
            }
        }
    }
     public void MoveParaAmarelo(){
         //float; 
        //Debug.Log( transform.position = new Vector3(Random.Range(1.6f,6.6f),Random.Range(5.08f,7.08f),0.0f));
        Debug.Log( transform.position += new Vector3(3f,6.08f,0.0f));
    }

     public void MoveParaAzul(){
        transform.position = new Vector3(Random.Range(-1f,2f),Random.Range(9f,12f),0.0f);
    }
}