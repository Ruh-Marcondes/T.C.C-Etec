﻿namespace SuperTiled2Unity
{
    public class SuperGroupLayer : SuperLayer
    {
    }
}
