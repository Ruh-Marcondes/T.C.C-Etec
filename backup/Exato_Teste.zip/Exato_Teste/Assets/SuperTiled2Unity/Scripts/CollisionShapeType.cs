﻿namespace SuperTiled2Unity
{
    public enum CollisionShapeType
    {
        Rectangle,
        Ellipse,
        Polygon,
        Polyline,
    }
}
