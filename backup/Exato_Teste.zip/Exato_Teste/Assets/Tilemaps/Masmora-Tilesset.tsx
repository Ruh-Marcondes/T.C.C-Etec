<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Masmora-Tilesset" tilewidth="32" tileheight="32" tilecount="55" columns="11">
 <image source="Masmorra-tileset.png" width="352" height="160"/>
 <terraintypes>
  <terrain name="Path" tile="12"/>
 </terraintypes>
 <tile id="15" terrain=",,,0"/>
 <tile id="16" terrain=",,0,0"/>
 <tile id="17" terrain=",,0,"/>
 <tile id="26" terrain=",0,,0"/>
 <tile id="27" terrain="0,0,0,0"/>
 <tile id="28" terrain="0,,0,"/>
 <tile id="37" terrain=",0,,"/>
 <tile id="38" terrain="0,0,,"/>
 <tile id="39" terrain="0,,,"/>
</tileset>
