using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPositions{
    public  static Vector3 playerRoom2_Masmorra = new Vector3(-4.11f,8.65f,0.0f);
    public  static Vector3 room3_Masmorra = new Vector3(-4.23f,21.24f,0.0f);
}
public class PosicoesCamera{
    public static Vector2 MaxPositionRoom2_Masmorra = new Vector2 (1.85f,16.31f); 
    public static Vector2 MinPositinRoom2_Masmorra = new Vector2(-8.12f,9.39f);
    public static Vector2 NewMaxPositionRoom2_Masmorra = new Vector2(14.3f,23f);
    public static Vector2 NewMinPositinRoom2_Masmorra = new Vector2(11.4f,8.2f);
    public static Vector2 Min_Room3_Masmorra = new Vector2(-8f,22.2f);
    public static Vector2 Max_Room3_Masmorra = new Vector2(1.7f,27.4f);
}